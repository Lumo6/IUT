var searchData=
[
  ['foreground_5fblue_0',['FOREGROUND_BLUE',['../test_8h.html#addf1a3ade056f8c56e9b4e4d06936876',1,'test.h']]],
  ['foreground_5fgreen_1',['FOREGROUND_GREEN',['../test_8h.html#ac7e7564b3b0cf8504f5af0f1330d1134',1,'test.h']]],
  ['foreground_5fintensity_2',['FOREGROUND_INTENSITY',['../test_8h.html#a100bd8947dfde0e36ef31bc6d2ee0d1d',1,'test.h']]],
  ['foreground_5fred_3',['FOREGROUND_RED',['../test_8h.html#aef543dc7ad78ec1b81e744bff6c9c075',1,'test.h']]]
];
