#include<iostream>
#include<vector>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include <array>
#include <cmath>

using tab_t = std::vector<std::vector<int>>;
using tab_entete = std::array<int, 3>;
using tab_ligne = std::vector<std::vector<std::string>>;
using tab_mot = std::vector<std::string>;

tab_entete entete(std::string);
/*{
Role: R�cup�rer les infos utiles en entetes tel que la longueur, la largeur
Entr�e(s): un string contenant le nom de l'image voulue
Sortie(s): un tableau d'entier avec les infos utiles
}*/

tab_t lectfich(std::string,tab_entete);
/*{
Role:
Entr�e(s): 
Sortie(s): 
}*/

tab_mot lectpalette(std::string);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/

tab_ligne ascii2art(unsigned int,unsigned int, tab_t, tab_mot);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/

tab_t resize(tab_t source, size_t origine_x, size_t origine_y, size_t multiplier);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/

unsigned int calcul_ratio(unsigned int, unsigned int , unsigned int, unsigned int, bool, bool);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/