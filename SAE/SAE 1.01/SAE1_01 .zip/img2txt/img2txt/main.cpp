#include"ascii_console.h"
#include"ascii_fonction.h"

#ifdef _WIN32
#include <Windows.h>
#endif //_WIN32

int main(int argc, char* argv[])
{
#ifdef _WIN32
	SetConsoleCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);
#endif //_WIN32

	int i = 0;
	std::string input = "meme.pgm";
	std::string nmpalette = "palette.txt";
	std::string output = "sortie.txt";
	unsigned int height = 50;
	bool hautrentree = false;
	unsigned int width = 50;
	bool longrentree = false;
	while (i < argc)
	{
		if ("--input" == std::string(argv[i]))
		{
			input = std::string(argv[i + 1]);

		}
		else if ("--palette" == std::string(argv[i]))
		{
			nmpalette = std::string(argv[i + 1]);
		}
		else if ("--output" == std::string(argv[i]))
		{
			output = std::string(argv[i + 1]);
		}
		else if ("--width" == std::string(argv[i]))
		{
			width = std::stoi(argv[i + 1]);
			longrentree = true;
		}
		else if ("--height" == std::string(argv[i]))
		{
			height = std::stoi(argv[i + 1]);
			hautrentree = true;
		}
		else if ("--help" == std::string(argv[i]))
		{

			std::cout << "Options:\n--input fichier\n\tSpécifie le fichier image à convertir\n\tSi ce paramètre n'est pas spécifié,\n\tle fichier est demandé via la console.\n\n--output fichier\n\tSpécifie le nom du fichier texte qui contiendra l'Ascii Art.\n\tSi ce paramètre n'est pas spécifié,\n\tl'Ascii Art est sortie dans la console.\n\n\n--palette fichier\n\tSpécifie un fichier texte contenant la palette de couleur Ascii.\n\tChaque ligne du fichier contient un charactère en UTF - 8,\n\tdu plus sombre au plus clair.\n\n\tSi ce paramètre n'est pas spécifié,\n\tla palette par défaut est \"W\", \"w\", \"1\", \"i\", \":\",\n\n--help\n\tAffiche cette aide.\n";
			std::cout << "\n--width\n\tSpécifie la largeur max de l'Ascii Art.\n\n\tSi ce paramètre n'est pas spécifié, aucune limite n'est fixée.Voir Remarques.\n\n--height\n\tSpécifie la hauteur max de l'Ascii Art.\n\n\tSi ce paramètre n'est pas spécifié, aucune limite n'est fixée.Voir Remarques.\n\nRemarques :\n\tQuelles que soient les valeurs des options --width et --height, la taille\n\tde l'Ascii Art est bornée par la taille de l'image en entrée.\n\tLa taille de l'ascii art conserve toujours le même ratio que l'image d'entrée,\n\tles valeurs des options --width et --height ne sont que des maximums.\n";

			exit(0);
		}
		i++;
	}


	/*std::string nom_fichier;
	std::string nom_palette;
	std::cout << "entrez le nom du fichier :"<<std::endl;
	std::cin >> nom_fichier;
	std::cout << "entrez le nom de la palette :"<<std::endl;
	std::cin >> nom_palette;*/
	//récupération du nom de la palette et de l'image voulues

	tab_entete entetes = entete(input);
	//Récupération des infos de l'entete

	tab_t tab = lectfich(input,entetes);
	//Récuperation des donnees du fichier pgm

	tab_mot palette = lectpalette(nmpalette);
	//Récupération de la palette
	unsigned int longueur = entetes[0];
	unsigned int hauteur = entetes[1];

	unsigned int ratio = calcul_ratio(longueur,hauteur , width, height, longrentree, hautrentree);

	tab_t resized = resize(tab, longueur, hauteur, ratio);

	tab_ligne fichier = ascii2art((longueur / ratio) - 1, (hauteur / ratio) - 1, resized, palette);
	//Utilisation de la palette et des donnees de l'image pour la convertir en ascii_art

	/*std::string nom_fout;
	std::cout << "entrez le nom du fichier de sortie :"<<std::endl;
	std::cin >> nom_fout;*/
	img2fich(fichier, std::string(output));
	//Ecriture de l'image convertit dans un fichier image F

	
}
