#include"ASCII_fonction.h"
tab_entete entete(std::string nom_fichier)
{
    int larg;
    int haut;
    int valeurmax;


    //unsigned char pt;
    std::ifstream fichier(nom_fichier + ".pgm", std::ios::binary);
    if (fichier.fail())
    {
        fichier.close();
    }
    std::string ligne;
    // 1ere ligne
    std::getline(fichier, ligne);
    bool binary = true;
    if (ligne == "P5")
    {
        binary = true;
    }
    else if (ligne == "P2")
    {
        binary = false;
    }
    else
    {
        fichier.close();
    }
    // on saut le commentaire eventuel
    std::getline(fichier, ligne);
    if (ligne[0] == '#')
    {
        std::getline(fichier, ligne);
    }
    // on obtient les dimensions
    std::istringstream is(ligne);
    is >> larg >> haut;
    // la valeur max

    fichier >> valeurmax;
    fichier.close();
    std::array<int, 3> retour = { larg,haut,valeurmax };
    return retour;
}

tab_t lectfich(std::string nom_fichier,tab_entete entetes)
{
    std::ifstream fichier(nom_fichier + ".pgm", std::ios::binary);
    if (!fichier.is_open())
    {
        std::cout << "aucun fichier en lecture";
        exit(1);
    }
    int pixtot = entetes[0] * entetes[1];
    std::vector<char> donneeschar(pixtot);
    for (int i = 0; i < 4; i++)
    {
        std::string ligne;
        std::getline(fichier, ligne);
    }
    fichier.read(donneeschar.data(), pixtot);
    tab_t donnees;
    donnees.reserve(entetes[1]);
    std::vector<int> valligne;
    valligne.reserve(entetes[0]);
    size_t cptVal = 0;

    for (auto val : donneeschar)
    {
        valligne.push_back(static_cast<int>(val));
        cptVal++;
        if (cptVal == entetes[0])
        {
            donnees.push_back(valligne);
            valligne = {};
            cptVal = 0;
        }
    }
    fichier.close();
    return donnees;
}

tab_mot lectpalette(std::string texte)
{
    tab_mot lettre;
    std::ifstream fichier(texte + ".txt");
    if (fichier.is_open())
    {
        std::string ligne;
        while (std::getline(fichier, ligne))
        {
            lettre.push_back(ligne);
        }
        fichier.close();
    }
    else
    {
        std::cerr << "Impossible d'ouvrir le fichier" << std::endl;
    }
    return lettre;
}

tab_ligne ascii2art(unsigned int longueur,unsigned int hauteur, tab_t valeurs, tab_mot lettre)
{
    tab_ligne tab;

    tab.resize(hauteur);

    for (int i = 0; i < hauteur; i++)
    {
        tab[i].resize(longueur);

        for (int j = 0; j < longueur; j++)
        {
            int val = valeurs[i][j];
            int k = val % lettre.size();
            tab[i][j] = lettre[k];
        }
    }
    return tab;
}

tab_t resize(tab_t source, size_t origine_x, size_t origine_y, size_t ratio)
{
    int newx = origine_x / ratio,
        newy = origine_y / ratio;
    //newx newy correspondent au nouvelles dimentions du tableau

    tab_t returned;

    returned.resize(newy);  // On resize la hauteur du tableau
    for (int i = 0; i < newy; ++i)
        returned[i].resize(newx); // on resize les lignes du tableau

    for (int i = 0,k=0;k<(newy) - (origine_y%ratio); i+=ratio,k++)
    {
        for (int j=0,l=0;l<(newx) - (origine_x%ratio); j+=ratio,l++) // on balaiye les cases du tableau a 2 dimensions
        {
            unsigned int moy = 0;
            for (int m = 0; m < ratio; m++) {   // on calcule la somme d'un carr� de taille ratio par ratio
                for (int n = 0; n < ratio; n++) {
                    moy += source[i + m][j + n];
                }
            }
            returned[k][l] += moy / (ratio*ratio); //on rentre la moyenne (calcul� par la somme sur le carr� du ratio) dans la case correspondante
        }
    }


    return returned;
}   

unsigned int calcul_ratio(unsigned int longueur, unsigned int hauteur, unsigned int width, unsigned int height,bool longrentree,bool hautrentree) {
    if (!longrentree) {
        width = longueur;
    }
    if (!hautrentree) {
        height = hauteur;
    }
    unsigned int ratioL = longueur / width;
    unsigned int ratioH = longueur / width;
    unsigned int ratio = 0;
    if (ratioL > ratioH) {
        ratio = ratioL;
    }
    else {
        ratio = ratioH;
    }
    return ratio;
}