#include"ASCII_console.h"

void affichimage(tab_ligne fichier)
{
	for (auto ligne : fichier)
	{
		for (auto car : ligne)
		{
			std::cout << car;
		}
		std::cout << std::endl;
	}
}

void img2fich(tab_ligne fichier, std::string filename)
{
	std::ofstream out_stream(filename+".txt", std::ios::binary);
	for (auto ligne : fichier)
	{
		for (auto car : ligne)
		{
			out_stream << car;
		}
		out_stream << std::endl;
	}
}
