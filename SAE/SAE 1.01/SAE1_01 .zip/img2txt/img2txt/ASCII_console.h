#include<iostream>
#include<vector>
#include<iomanip>
#include"ascii_fonction.h"

void affichimage(tab_ligne);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/

void img2fich(tab_ligne, std::string);
/*{
Role:
Entr�e(s):
Sortie(s):
}*/
