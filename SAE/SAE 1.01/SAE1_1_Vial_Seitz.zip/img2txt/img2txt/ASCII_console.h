#include<iostream>
#include<vector>
#include<iomanip>
#include"ascii_fonction.h"

void affichimage(tab_ligne);
/*{
Role: Afficher l'image obtenue en ASCII 
Entr�e(s): le tableau contenant les donn�es
Sortie(s):
}*/

void img2fich(tab_ligne, std::string);
/*{
Role: Enregistrer les donn�es obtenues au format .txt pour pouvoir l'ouvrir ult�rieurement avec un autre editeur de texte
Entr�e(s): le tableau contenant les donn�es, un string correspondant au nom du fichier
Sortie(s): un fichier correspondant au l'image en ASCII enregistr� dans le dossier source
}*/
