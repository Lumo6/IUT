#include"ascii_console.h"
#include"ascii_fonction.h"

#ifdef _WIN32
#include <Windows.h>
#endif //_WIN32

int main(int argc, char* argv[])
{
#ifdef _WIN32
	SetConsoleCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);
#endif //_WIN32

	int i = 0;
	std::string input = "meme.pgm";
	std::string nmpalette = "palette.txt";
	std::string output = "sortie.txt";
	unsigned int height = 50;
	bool hautrentree = false;
	unsigned int width = 50;
	bool longrentree = false;
	while (i < argc)
	{
		if ("--input" == std::string(argv[i]))
		{
			input = std::string(argv[i + 1]);

		}
		else if ("--palette" == std::string(argv[i]))
		{
			nmpalette = std::string(argv[i + 1]);
		}
		else if ("--output" == std::string(argv[i]))
		{
			output = std::string(argv[i + 1]);
		}
		else if ("--width" == std::string(argv[i]))
		{
			width = std::stoi(argv[i + 1]);
			longrentree = true;
		}
		else if ("--height" == std::string(argv[i]))
		{
			height = std::stoi(argv[i + 1]);
			hautrentree = true;
		}
		else if ("--help" == std::string(argv[i]))
		{

			std::cout << "Options:\n--input fichier\t\tSpécifie le fichier image à convertir\n\t\t\tSi ce paramètre n'est pas spécifié, le fichier est demandé via la \n\t\t\tconsole.\n\n--output fichier\tSpécifie le nom du fichier texte qui contiendra l'Ascii Art.\n\t\t\tSi ce paramètre n'est pas spécifié, l'Ascii Art est sortie dans la \n\t\t\tconsole.\n\n\n--palette fichier\tSpécifie un fichier texte contenant la palette de couleur Ascii.\n\t\t\tChaque ligne du fichier contient un charactère en UTF - 8, du plus \n\t\t\tsombre au plus clair.\n\t\t\tSi ce paramètre n'est pas spécifié, la palette par défaut \n\t\t\test \"W\", \"w\", \"1\", \"i\", \":\",\n\n--help\t\t\tAffiche cette aide.\n";
			std::cout << "\n--width\t\t\tSpécifie la largeur max de l'Ascii Art.\n\t\t\tSi ce paramètre n'est pas spécifié, aucune limite n'est fixée.\n\t\t\tVoir Remarques.\n\n--height\t\tSpécifie la hauteur max de l'Ascii Art.\n\t\t\tSi ce paramètre n'est pas spécifié, aucune limite n'est fixée.\n\t\t\tVoir Remarques.\n\nRemarques :\nQuelles que soient les valeurs des options --width et --height, la taille de l'Ascii Art \nest bornée par la taille de l'image en entrée. La taille de l'ascii art conserve \ntoujours le même ratio que l'image d'entrée, les valeurs des options --width et --height \nne sont que des maximums.\n";
			exit(0);
		}
		i++;
	}


	/* Version 3
	std::string nom_fichier;
	std::string nom_palette;
	std::cout << "entrez le nom du fichier :"<<std::endl;
	std::cin >> nom_fichier;
	std::cout << "entrez le nom de la palette :"<<std::endl;
	std::cin >> nom_palette;*/
	//récupération du nom de la palette et de l'image voulues

	tab_entete entetes = entete(input);
	//Récupération des infos de l'entete

	tab_t tab = lectfich(input,entetes);
	//Récuperation des donnees du fichier pgm

	tab_mot palette = lectpalette(nmpalette);
	//Récupération de la palette
	unsigned int longueur = entetes[0];
	unsigned int hauteur = entetes[1];

	unsigned int ratio = calcul_ratio(longueur,hauteur , width, height, longrentree, hautrentree);

	tab_t resized = resize(tab, longueur, hauteur, ratio);

	tab_ligne fichier = ascii2art((longueur / ratio) - 1, (hauteur / ratio) - 1, resized, palette);
	//Utilisation de la palette et des donnees de l'image pour la convertir en ascii_art

	/* Version 2
	std::string nom_fout;
	std::cout << "entrez le nom du fichier de sortie :"<<std::endl;
	std::cin >> nom_fout;*/
	img2fich(fichier, std::string(output));
	//Ecriture de l'image convertie dans un fichier image F

	
}
