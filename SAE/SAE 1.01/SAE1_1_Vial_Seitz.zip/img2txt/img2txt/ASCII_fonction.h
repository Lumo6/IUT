#include<iostream>
#include<vector>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include <array>
#include <cmath>

using tab_t = std::vector<std::vector<int>>;
using tab_entete = std::array<int, 3>;
using tab_ligne = std::vector<std::vector<std::string>>;
using tab_mot = std::vector<std::string>;

tab_entete entete(std::string);
/*{
Role: R�cup�rer les infos utiles en entete telles que la longueur et la largeur
Entr�e(s): un string contenant le nom de l'image voulue
Sortie(s): un tableau d'entiers avec les infos utiles
}*/

tab_t lectfich(std::string,tab_entete);
/*{
Role: Lire les donn�es du fichier en omettant l'en-t�te
Entr�e(s): un string contenant le nom du fichier / tableau contenant l'en-t�te
Sortie(s): un tableau d'entiers contenant les caract�res obtenus apr�s le passage par img2pgm
}*/

tab_mot lectpalette(std::string);
/*{
Role: R�cup�rer les informations sur la palette � utiliser
Entr�e(s): un string contenant le nom du fichier
Sortie(s): un tableau de caract�res permettant la transcription
}*/

tab_ligne ascii2art(unsigned int,unsigned int, tab_t, tab_mot);
/*{
Role: Transcrire les informations obtenues lors de la lecture de fichier
Entr�e(s): entiers : longueur, largeur / tableaux:  version � convertir, version convertie
Sortie(s): Les caract�res alphanum�riques obtenus apr�s la transcription
}*/

tab_t resize(tab_t source, size_t origine_x, size_t origine_y, size_t multiplier);
/*{
Role: Redimensionner l'image obtenue
Entr�e(s): le tableau de l'image source, ses tailles, et le ratio de redimension
Sortie(s): le tableau de l'image redimensionn�
}*/

unsigned int calcul_ratio(unsigned int, unsigned int , unsigned int, unsigned int, bool, bool);
/*{
Role: Calculer le ratio pour redimensionner l'image
Entr�e(s): entiers : tailles initiales, tailles recherch�es apr�s redimensionnement
Sortie(s): la valeur de ratio pour le redimensionnement
}*/