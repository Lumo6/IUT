var class_c_circular_buffer =
[
    [ "CCircularBuffer", "class_c_circular_buffer.html#a959ca03b1705fb5761551323cdf36879", null ],
    [ "size", "class_c_circular_buffer.html#a259cb5a711406a8c3e5d937eb9350cca", null ],
    [ "freeSpace", "class_c_circular_buffer.html#a5987d6ad93e01d85904bb6533720ab3a", null ],
    [ "usedSpace", "class_c_circular_buffer.html#a1f6d80f3a6404a0c8a9e49b7f9a03ac4", null ],
    [ "rawData", "class_c_circular_buffer.html#a4bfa1510f26143ed9d4dda9d5e8ff4fe", null ],
    [ "read", "class_c_circular_buffer.html#ae0e8b28a31b98880a2203cf998413d3b", null ],
    [ "write", "class_c_circular_buffer.html#a4b4678410b13671afbdec891d3e95a2e", null ],
    [ "unrollTo", "class_c_circular_buffer.html#a78d46de873e3fbb68f9c6054169b23ba", null ],
    [ "m_nSizeBitmask", "class_c_circular_buffer.html#a2503cb29b73bfab89557f6e5e5814d9a", null ],
    [ "m_data", "class_c_circular_buffer.html#a4252108bbe731880b31e853b01cd16d0", null ],
    [ "m_readPos", "class_c_circular_buffer.html#ab17965c46d3fa97b7fd0534424fccd41", null ],
    [ "m_writePos", "class_c_circular_buffer.html#a17be3c8e94cb594b9da50a5adeeb825f", null ],
    [ "m_bEmpty", "class_c_circular_buffer.html#a5c3ecd91871c5d14ab5363d20175174b", null ]
];