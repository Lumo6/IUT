var annotated_dup =
[
    [ "CCircularBuffer", "class_c_circular_buffer.html", "class_c_circular_buffer" ],
    [ "CCircularBufferError", "class_c_circular_buffer_error.html", "class_c_circular_buffer_error" ],
    [ "CSender", "class_c_sender.html", "class_c_sender" ]
];