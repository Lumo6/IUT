var class_c_sender =
[
    [ "CSender", "class_c_sender.html#ad88cf2fc149d41614e4e44c095182632", null ],
    [ "SendNextPacket", "class_c_sender.html#aa30f8a5608d52033e3fa32b1588c8b44", null ],
    [ "m_strText", "class_c_sender.html#a5b1c65d40eee6ef9f03edfed4a1d3aa6", null ],
    [ "m_lstPackets", "class_c_sender.html#ac80c4770e09374f8535263ef35e5b5a2", null ],
    [ "m_itCurPacket", "class_c_sender.html#a9e2021bd6bbd5b0acd36bdc3d2d64baf", null ]
];