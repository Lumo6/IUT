var files_dup =
[
    [ "TP 23", "dir_0b5052d87a21c1d0c2f8d6a213864873.html", "dir_0b5052d87a21c1d0c2f8d6a213864873" ],
    [ "TP 23 - streaming", "dir_78933daa9f25dc6405c7abeeca2eba4e.html", "dir_78933daa9f25dc6405c7abeeca2eba4e" ]
];