var class_c_circular_buffer_error =
[
    [ "ErrorCodes", "class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3", [
      [ "UnknownError", "class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3abfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "SizeIsNotPowerOf2", "class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3ae6a1a7e5844862e3ffb0571f1870c4cc", null ],
      [ "NotEnoughFreeSpace", "class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3afab646c96b4558b595437348f4e23d00", null ]
    ] ],
    [ "CCircularBufferError", "class_c_circular_buffer_error.html#a282cd38a97e922f50971472cd3eae54d", null ],
    [ "errorCode", "class_c_circular_buffer_error.html#aaa8182c5f8926cd3be8cadc017ae6134", null ],
    [ "what", "class_c_circular_buffer_error.html#a577538bc3a0f9b1f43cc3d5d63025638", null ],
    [ "m_nErrorCode", "class_c_circular_buffer_error.html#aa0944d1695962341f6880dc2ef04a5e0", null ],
    [ "m_strError", "class_c_circular_buffer_error.html#ac3ebcca84bc4a0e477b8714d9c7d2b81", null ]
];