var searchData=
[
  ['notenoughfreespace_0',['NotEnoughFreeSpace',['../class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3afab646c96b4558b595437348f4e23d00',1,'CCircularBufferError']]]
];
