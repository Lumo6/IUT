var searchData=
[
  ['unknownerror_0',['UnknownError',['../class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3abfaef30f1c8011c5cefa38ae470fb7aa',1,'CCircularBufferError']]],
  ['unrollto_1',['unrollTo',['../class_c_circular_buffer.html#a78d46de873e3fbb68f9c6054169b23ba',1,'CCircularBuffer']]],
  ['usedspace_2',['usedSpace',['../class_c_circular_buffer.html#a1f6d80f3a6404a0c8a9e49b7f9a03ac4',1,'CCircularBuffer']]]
];
