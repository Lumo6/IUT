var searchData=
[
  ['sizeisnotpowerof2_0',['SizeIsNotPowerOf2',['../class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3ae6a1a7e5844862e3ffb0571f1870c4cc',1,'CCircularBufferError']]]
];
