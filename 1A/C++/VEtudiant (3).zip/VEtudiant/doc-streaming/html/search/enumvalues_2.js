var searchData=
[
  ['unknownerror_0',['UnknownError',['../class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3abfaef30f1c8011c5cefa38ae470fb7aa',1,'CCircularBufferError']]]
];
