var searchData=
[
  ['errorcode_0',['errorCode',['../class_c_circular_buffer_error.html#aaa8182c5f8926cd3be8cadc017ae6134',1,'CCircularBufferError']]],
  ['errorcodes_1',['ErrorCodes',['../class_c_circular_buffer_error.html#a3878e89dc5c88d823f4f923ef90dbcb3',1,'CCircularBufferError']]]
];
