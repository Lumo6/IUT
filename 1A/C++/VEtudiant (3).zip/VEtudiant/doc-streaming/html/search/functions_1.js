var searchData=
[
  ['errorcode_0',['errorCode',['../class_c_circular_buffer_error.html#aaa8182c5f8926cd3be8cadc017ae6134',1,'CCircularBufferError']]]
];
