var searchData=
[
  ['unrollto_0',['unrollTo',['../class_c_circular_buffer.html#a78d46de873e3fbb68f9c6054169b23ba',1,'CCircularBuffer']]],
  ['usedspace_1',['usedSpace',['../class_c_circular_buffer.html#a1f6d80f3a6404a0c8a9e49b7f9a03ac4',1,'CCircularBuffer']]]
];
