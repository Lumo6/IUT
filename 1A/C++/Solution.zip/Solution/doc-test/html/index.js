var index =
[
    [ "Objectifs du TP", "index.html#sec0", null ],
    [ "Exercice 1 Génération d’une erreur", "index.html#sec1", null ],
    [ "Exercice 2 Création d’une classe d’erreur", "index.html#sec2", null ],
    [ "Exercice 3 Utilisation de la classe d’erreur", "index.html#sec3", null ],
    [ "Exercice 4 Test complet", "index.html#sec4", null ]
];