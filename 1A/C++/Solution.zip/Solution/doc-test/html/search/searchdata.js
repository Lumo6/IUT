var indexSectionsWithContent =
{
  0: "1234bcdefghilmnopstuzà–",
  1: "c",
  2: "empst",
  3: "cgimoz",
  4: "m",
  5: "befhnt",
  6: "12cdeflmtà–"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

