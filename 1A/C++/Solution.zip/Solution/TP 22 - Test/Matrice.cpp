/*!
 * \file  "Matrice.cpp"
 *
 * \brief Définition de la classe CMatrice. 
 *
 * \author Benjamin ALBOUY-KISSI
 * \date 2016
 *
 * \todo
 * 1) Copiez ici le contenu du fichier Matrice.cpp du TP 9, puis modifiez la classe 
 * de sorte à ajouter la gestion d'erreur.\n
 */
#include "StdAfx.h"
