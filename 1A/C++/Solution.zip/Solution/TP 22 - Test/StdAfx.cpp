/*!
 * \file "StdAfx.cpp"
 * 
 * \author Benjamin ALBOUY-KISSI
 * \version 2012
 * \date 2016
 *
 * \brief Fichier de gestion des en-têtes précompilées.
 *
 * Ce fichier ne sert à rien d'autre que de créer l'en-tête précompilé.
 *
 */

#include "StdAfx.h"

