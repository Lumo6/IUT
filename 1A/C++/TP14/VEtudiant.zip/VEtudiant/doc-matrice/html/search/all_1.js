var searchData=
[
  ['getnbcols_0',['GetNbCols',['../class_c_matrice.html#a69b8790b2f7b3ea519822dbd9bcbb64b',1,'CMatrice']]],
  ['getnbrows_1',['GetNbRows',['../class_c_matrice.html#a12a846810e53c25145c679becad5d986',1,'CMatrice']]]
];
