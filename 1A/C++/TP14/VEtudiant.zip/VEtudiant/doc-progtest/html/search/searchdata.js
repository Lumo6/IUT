var indexSectionsWithContent =
{
  0: "dfmpt",
  1: "p",
  2: "m",
  3: "dft"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Pages"
};

