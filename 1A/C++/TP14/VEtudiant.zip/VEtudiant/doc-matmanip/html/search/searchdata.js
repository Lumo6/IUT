var indexSectionsWithContent =
{
  0: "acdefmstu",
  1: "fmu",
  2: "acdems",
  3: "dft"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Pages"
};

