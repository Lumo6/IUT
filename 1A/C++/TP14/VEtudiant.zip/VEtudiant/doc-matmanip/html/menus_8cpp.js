var menus_8cpp =
[
    [ "menu", "menus_8cpp.html#a50933ad80c68659a29f7da143cd9e527", null ],
    [ "MenuPrincipal", "menus_8cpp.html#a6d65f4bf4b49548c10ff609a37116201", null ],
    [ "MenuOperations", "menus_8cpp.html#af84faf18163fe94dea44d12cffb0f448", null ],
    [ "MenuVerifications", "menus_8cpp.html#a7ee3c0d259ab010c7587ef1ad73540fa", null ]
];